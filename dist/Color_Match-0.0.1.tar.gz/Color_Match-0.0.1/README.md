# Color-Matching

This package contains utility functions for creating perceptually equivalent colors to those of a known spectrum when only having access to certain, fixed-wavelength sources.

In other words, if you've every wondered "how do I make 3800K light with RGB LEDs?", then this package is for you.
